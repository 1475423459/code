# coding=utf-8
def recive():
    print("已接受到消息")

if __name__ == "__main__":
    recive()