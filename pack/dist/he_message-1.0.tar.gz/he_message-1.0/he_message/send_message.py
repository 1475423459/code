# coding=utf-8
def send(text):
    print("正在发送消息：%s....." % text)

if __name__ =="__main__":
    send("你好")